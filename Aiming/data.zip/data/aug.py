import Augmentor

p = Augmentor.Pipeline("red2")
p.flip_random(1)
p.random_contrast(.2, .9, 1.1)
p.random_brightness(.2, 0.9, 1.1)
p.random_erasing(.25, 0.3)
p.rotate_random_90(1)
p.rotate(.2, max_left_rotation=15, max_right_rotation=15)


p.sample(8700)
